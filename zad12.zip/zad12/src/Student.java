public class Student {
    public String name = "prywat";
    public String surname = "prywat";
    public int birthYear = 0000;
    public Student(String a, String b, int c){
        this.name = a;
        this.surname = b;
        this.birthYear = c;
    }
}