public class Secretstudent {
    public String name = "prywat name";
    public String surname = "prywat name";
    public int birthYear = 0000;
    public Secretstudent(String a, String b, int c){
        this.name = a;
        this.surname = b;
        this.birthYear = c;
    }
}