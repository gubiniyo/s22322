import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        printStaticHello();
        Student student1 = new Student ("Mikita", "Hubko", 2003);
        System.out.println(student1.name + " " + student1.surname + " " + student1.birthYear);
        Student student2 = new Student ("Ihar","Biazliudau",2005);
        System.out.println(student2.name + " " + student2.surname + " " + student2.birthYear);
        Secretstudent secret1 = new Secretstudent("imie prywatne", "nazwisko prywatnie", 0000);
        Secretstudent secret2 = new Secretstudent("Palina", "Hubko", 2002);
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Write a key:");
        String word = keyboard.nextLine();
        if (word == "reveal"){
            System.out.println(secret2.name + " " + secret2.surname + " " + secret2.birthYear);
        }
        else{
            System.out.println(secret1.name + " " + secret1.surname + " " + secret1.birthYear);
        }
    }
    public static void printStaticHello(){
        System.out.println("Hello");
    }
    public void printHello(){
        System.out.println("Hello");
    }
}