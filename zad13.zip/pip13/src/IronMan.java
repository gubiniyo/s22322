public class IronMan {

    public ironMan (RegularPerson.tony) {

        this.tony = tony;

    }

    public attack () {

        int i = (int)(1+Math.random()*1);
        switch (i) {

            case 1:
                System.out.println("Iron Man attacks Justin Hammer!");
                break;
            case 2:
                System.out.println("Iron Man missed hit!");
        }

    }

    public printNameOfOwner () {

        System.out.println("Tony Stark.");

    }

    public goParty () {

        System.out.println("Party time.");

    }

}
