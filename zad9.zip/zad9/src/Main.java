import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        System.out.println("Wpisz liczby dla Fibonacci: ");
        int n = console.nextInt();

        // zad 1

        System.out.println("Zadanie 1");
        int r1 = zd1(n);
        System.out.println(r1);

        //zaad 2

        System.out.println("Zadanie 2");
        int r2 = zd2(n);
        System.out.println(r2);

        //zad 3

        System.out.println("Zadanie 3");
        System.out.println("Wpisz ilosc liczb:");
        int qwe = console.nextInt();
        int array[] = new int[qwe];
        System.out.println("Wpisz liczbe:");
        for (int i = 0; i < qwe; i++) {
            array[i] = console.nextInt();}
        System.out.println("Poczatkowy typ: ");
        for (int i = 0; i <= array.length - 1; i++) {
            System.out.print(array[i] + " ");}
        System.out.println();
        System.out.println("Odwrotny typ: ");
        zd3(array);
        System.out.println();

        // zad 4

        System.out.println("Zadanie 4");
        System.out.println("Wpisz klucz: ");
        int key = console.nextInt();
        zd4(array, key);
    }
    public static int zd1(int n){
        int a = 0;
        int b = 1;
        int c = 0;
        for (int i = 0; i < n; i++){
            c = a;
            a = b;
            b = c + b;
        }
        return(a);
    }
    public static int zd2(int n) {
        if (n == 0) {
            return 0;
        } else if (n == 1) {
            return 1;
        } else {
            return zd2(n - 1) + zd2(n - 2);
        }
    }
    static void zd3(int array[]){
        for (int i = array.length - 1; i >= 0; i--){
            System.out.print(array[i]+" ");
        }
    }
    static void zd4(int array[], int key){
        boolean is = false;
        while (!is){
            for (int i = 0; i <= array.length - 1; i++) {
                if (array[i]==key){
                    System.out.println(array[i]+" Klucz");
                    is = true;
                    break;
                }
                else{
                    System.out.println(array[i]+" Nie klucz");
                }
            }
        }
    }
}