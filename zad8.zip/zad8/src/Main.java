import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Wpisz n:");
        int n = keyboard.nextInt();
        keyboard.close();
        int[] genArr1 = new int[n];
        for (int i = 0; i < n; i++) {
            genArr1[i] = (int) (Math.random() * 100);
        }
        genArrUserDisplay(genArr1);
        genArrSort(genArr1);
        int[] genArr2 = new int[n];
        keyboard.close();
        for (int i = 0; i < n; i++) {
            genArr2[i] = (int) (Math.random() * 100);
        }
        genArrRandomDisplay(genArr2);
        genArrsRev(genArr1, genArr2, n);
    }

    public static void genArrUserDisplay(int genArr[]) {
        for (int i = 0; i < genArr.length; i++) {
            System.out.print(genArr[i] + ", ");
        }
        System.out.println();
    }
    public static void genArrRandomDisplay(int genArr[]) {
        for (int i = 0; i < genArr.length; i++) {
            System.out.print(genArr[i] + ", ");
        }
        System.out.println();
    }
    public static void genArrSortDisplay(int genArr[]) {
        for (int i = 0; i < genArr.length; i++) {
            System.out.print(genArr[i] + ", ");
        }
        System.out.println();
    }

    public static void genArrSort(int genArrSort[]){
        int temp;
        boolean sorted = false;
        while(!sorted) {
            sorted = true;
            for (int i = 0; i < genArrSort.length - 1; i++) {
                if (genArrSort[i] > genArrSort[i+1]) {
                    temp = genArrSort[i];
                    genArrSort[i] = genArrSort[i+1];
                    genArrSort[i+1] = temp;
                    sorted = false;}
            }}
        genArrSortDisplay(genArrSort);
    }
    public static void genArrReverseDisplay (int[] genArrReverse) {
        for (int i = genArrReverse.length - 1; i >= 0; i--) {
            System.out.print(genArrReverse[i]+", ");
        }
        System.out.println();
    }
    public static void  genArrsRev(int[] genArr1, int[] genArr2, int n){
        boolean rev = false;
        while (true){
            for (int i = 1; i < n; i++){
                do {
                    if (genArr1[i] != genArr2[n - i]) {
                        rev = true;
                    }
                }
                while (rev != false);
            }
        }
    }
}
