import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class Main {
    public static void main(String[] args) {
        String[][] data = readDataFromFile("src/data.txt");
        displayData(data);
    }
    public static String[][] readDataFromFile(String filePath) {
        String[][] data = new String[10][];
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            int i = 0;
            while ((line = br.readLine()) != null) {
                data[i++] = splitBy(line, ",");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }
    public static String[] splitBy(String line, String separator) {
        return line.split(separator);
    }
    public static void displayData(String[][] data) {
        for (String[] row : data) {
            for (String cell : row) {
                System.out.print(cell + " ");
            }
            System.out.println();
        }
    }
}
